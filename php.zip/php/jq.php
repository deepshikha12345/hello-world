<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<style type="text/css">
.box{
    margin: 10px;
    float: left;
    width: 100px;
    height: 50px;
    border: solid 1px ;
}
.active{
border:1px solid;
 margin: 10px;
    float: left;
    width: 100px;
    height: 50px;
border-color:red;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
    
 $('.box').click(function(){
 if($('.active').length){
$('.active').not($(this)).removeClass('active').addClass('box');
}      
$(this).removeClass('box').addClass('active');     
}); 
     
});
</script>
 
 
    </head>
    <body>
    <div class="box active"></div>
    <div class="box"></div>
    <div class="box"></div>
    <div class="box"></div>
    </body>